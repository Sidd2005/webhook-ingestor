# Prometheus metrics setup
def setup_metrics(app):
    pass
